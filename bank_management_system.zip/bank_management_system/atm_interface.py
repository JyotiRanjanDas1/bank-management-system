import streamlit as st


# ---------------- SESSION ----------------

if "accounts" not in st.session_state:
    st.session_state.accounts = {
        1001: {"name": "Rahul", "pin": 1234, "balance": 5000},
        1002: {"name": "Priya", "pin": 4321, "balance": 8000}
    }

if "user" not in st.session_state:
    st.session_state.user = None

if "page" not in st.session_state:
    st.session_state.page = "login"


# ---------------- ATM CLASS ----------------

class ATM:

    def __init__(self, acc):
        self.acc = acc


    # Object Method
    def check_balance(self):
        return st.session_state.accounts[self.acc]["balance"]


    # Object Method
    def deposit(self, amount):
        bal = self.check_balance()
        st.session_state.accounts[self.acc]["balance"] = self.add(bal, amount)


    # Object Method
    def withdraw(self, amount):
        bal = self.check_balance()

        if amount > bal:
            return "Insufficient Balance"

        st.session_state.accounts[self.acc]["balance"] = self.subtract(bal, amount)


    # Static Methods
    @staticmethod
    def add(a, b):
        return a + b

    @staticmethod
    def subtract(a, b):
        return a - b


# ---------------- UI ----------------

st.title("🏧 Python ATM Machine")


# ---------------- LOGIN PAGE ----------------

if st.session_state.page == "login":

    st.subheader("Insert Card")

    acc = st.number_input("Account Number", step=1)
    pin = st.number_input("PIN", step=1)

    if st.button("Login"):

        if acc in st.session_state.accounts:

            if st.session_state.accounts[acc]["pin"] == pin:
                st.session_state.user = acc
                st.session_state.page = "menu"
                st.success("Login Successful")
                st.rerun()

            else:
                st.error("Incorrect PIN")

        else:
            st.error("Account Not Found")


# ---------------- MENU ----------------

elif st.session_state.page == "menu":

    acc = st.session_state.user
    name = st.session_state.accounts[acc]["name"]

    atm = ATM(acc)

    st.subheader(f"Welcome {name}")

    col1, col2 = st.columns(2)

    with col1:
        if st.button("💰 Check Balance"):
            st.session_state.page = "balance"

        if st.button("💳 Deposit Money"):
            st.session_state.page = "deposit"

    with col2:
        if st.button("🏧 Withdraw Money"):
            st.session_state.page = "withdraw"

        if st.button("❌ Exit"):
            st.session_state.user = None
            st.session_state.page = "login"
            st.rerun()


# ---------------- BALANCE ----------------

elif st.session_state.page == "balance":

    acc = st.session_state.user
    atm = ATM(acc)

    balance = atm.check_balance()

    st.success(f"Your Balance: ₹{balance}")

    if st.button("Back"):
        st.session_state.page = "menu"
        st.rerun()


# ---------------- DEPOSIT ----------------

elif st.session_state.page == "deposit":

    acc = st.session_state.user
    atm = ATM(acc)

    amount = st.number_input("Enter Amount")

    if st.button("Deposit"):
        atm.deposit(amount)
        st.success("Deposit Successful")

    if st.button("Back"):
        st.session_state.page = "menu"
        st.rerun()


# ---------------- WITHDRAW ----------------

elif st.session_state.page == "withdraw":

    acc = st.session_state.user
    atm = ATM(acc)

    amount = st.number_input("Enter Amount")

    if st.button("Withdraw"):

        msg = atm.withdraw(amount)

        if msg:
            st.error(msg)
        else:
            st.success("Please Collect Your Cash 💵")

    if st.button("Back"):
        st.session_state.page = "menu"
        st.rerun()